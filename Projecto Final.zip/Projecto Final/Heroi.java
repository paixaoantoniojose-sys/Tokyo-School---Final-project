import java.util.Random;

public abstract class Heroi extends Personagem {

    public Heroi(String nome, int vida, int armadura) {
        super(nome, vida, armadura);
    }

    @Override
    public int atacar(Personagem adversario) {
        Random rand = new Random();
        int dado1 = rand.nextInt(101); // Lança o primeiro dado entre 0 e 100
        int dado2 = rand.nextInt(101); // Lança o segundo dado entre 0 e 100
        int ataque = Math.max(dado1, dado2); // Escolhe o maior valor

        // Personalizações de ataque para cada tipo de herói
        if (this instanceof Elfo && adversario instanceof Orco) {
            ataque += 10; // Bonus para Elfos atacando Orcos
        }

        // Calculando o dano
        if (ataque > adversario.getArmadura()) {
            return ataque - adversario.getArmadura();
        }
        return 0;
    }

}
