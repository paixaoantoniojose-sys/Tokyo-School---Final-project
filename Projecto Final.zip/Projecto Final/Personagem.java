
import java.util.Random;

public abstract class Personagem {
    protected String nome;
    protected int vida;
    protected int armadura;

    public Personagem(String nome, int vida, int armadura) {
        this.nome = nome;
        this.vida = vida;
        this.armadura = armadura;
    }

    public abstract int atacar(Personagem adversario);

    public void receberDano(int dano) {
        this.vida -= dano;
        if (this.vida < 0) this.vida = 0;
    }
    public boolean estaVivo() {
        return this.vida > 0;
    }
    public String getNome() {
        return nome;
    }
    public int getVida() {
        return vida;
    }
    public int getArmadura() {
        return armadura;
    }
}
