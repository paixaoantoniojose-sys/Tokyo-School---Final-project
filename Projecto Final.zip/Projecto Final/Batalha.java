import java.util.ArrayList;
import java.util.List;

public class Batalha {

    private final List<Personagem> exercitoHerois = new ArrayList<>();
    private final List<Personagem> exercitoBestas = new ArrayList<>();

    public void adicionarHeroi(Heroi heroi) {
        exercitoHerois.add(heroi);
    }

    public void adicionarBesta(Besta besta) {
        exercitoBestas.add(besta);
    }

    public void iniciarBatalha() {
        int turno = 1;
        while (!exercitoHerois.isEmpty() && !exercitoBestas.isEmpty()) {
            System.out.println("Turno " + turno);
            for (int i = 0; i < Math.min(exercitoHerois.size(), exercitoBestas.size()); i++) {
                Personagem heroi = exercitoHerois.get(i);
                Personagem besta = exercitoBestas.get(i);

                int danoHeroi = heroi.atacar(besta);
                besta.receberDano(danoHeroi);
                System.out.println(heroi.getNome() + " ataca " + besta.getNome() + " e causa " + danoHeroi + " de dano.");

                if (!besta.estaVivo()) {
                    System.out.println(besta.getNome() + " morreu!");
                    exercitoBestas.remove(i);
                }

                int danoBesta = besta.atacar(heroi);
                heroi.receberDano(danoBesta);
                System.out.println(besta.getNome() + " ataca " + heroi.getNome() + " e causa " + danoBesta + " de dano.");

                if (!heroi.estaVivo()) {
                    System.out.println(heroi.getNome() + " morreu!");
                    exercitoHerois.remove(i);
                }
            }
            turno++;
        }

        if (exercitoHerois.isEmpty()) {
            System.out.println("As Bestas venceram!");
        } else {
            System.out.println("Os Heróis venceram!");
        }
    }
}

