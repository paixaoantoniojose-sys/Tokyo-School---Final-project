public class Main {
    public static void main(String[] args) {
        // Criar heróis
        Elfo legolas = new Elfo("Legolas", 150, 30);
        Heroi aragorn = new Heroi("Aragorn", 150, 50) {};


        // Criar bestas
        Orco lurtz = new Orco("Lurtz", 200, 60);
        Besta uguk = new Besta("Ugluk", 120, 30) {};

        // Criar a batalha
        Batalha batalha = new Batalha();
        batalha.adicionarHeroi(legolas);
        batalha.adicionarHeroi(aragorn);
        batalha.adicionarBesta(lurtz);
        batalha.adicionarBesta(uguk);


        // Iniciar a batalha
        batalha.iniciarBatalha();
    }
}