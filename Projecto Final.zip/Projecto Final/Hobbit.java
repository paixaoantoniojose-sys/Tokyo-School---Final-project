public class Hobbit extends Heroi{
    public Hobbit(String nome, int vida, int armadura) {
        super(nome, vida, armadura);
    }
}
