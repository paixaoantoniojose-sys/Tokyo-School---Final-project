
public class Orco extends Besta {

    public Orco(String nome, int vida, int armadura) {
        super(nome, vida, armadura);
    }

    @Override
    public int atacar(Personagem adversario) {
        int dano = super.atacar(adversario);
        return dano;
    }
}

