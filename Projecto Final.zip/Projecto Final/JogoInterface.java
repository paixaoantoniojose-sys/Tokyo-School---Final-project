import javax.swing.*;
        import java.awt.*;
        import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JogoInterface extends JFrame {
    private final JTextArea areaTexto;
    private final JButton iniciarBatalhaButton;
    private final JButton adicionarHeroiButton;
    private final JButton adicionarBestaButton;
    private final JComboBox<String> comboBoxHerois;
    private final JComboBox<String> comboBoxBestas;
    private final Batalha batalha;

    public JogoInterface() {
        setTitle("Jogo do Senhor dos Anéis");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Criando os exércitos
        batalha = new Batalha();

        // Painel superior com botões e comboBoxes
        JPanel painelSuperior = new JPanel();
        painelSuperior.setLayout(new GridLayout(3, 2));

        // ComboBox para selecionar heróis
        comboBoxHerois = new JComboBox<>(new String[]{"Legolas (Elfo)", "Aragorn (Humano)","Boromir","Gandalf","Frodo"});
        painelSuperior.add(new JLabel("Escolha um Herói:"));
        painelSuperior.add(comboBoxHerois);

        // ComboBox para selecionar bestas
        comboBoxBestas = new JComboBox<>(new String[]{"Lurtz (Orco)", "Ugluk (Troll)","Shagra","Mauhúr"});
        painelSuperior.add(new JLabel("Escolha uma Besta:"));
        painelSuperior.add(comboBoxBestas);

        // Botão para adicionar herói ao exército
        adicionarHeroiButton = new JButton("Adicionar Herói");
        adicionarHeroiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarHeroi();
            }
        });
        painelSuperior.add(adicionarHeroiButton);

        // Botão para adicionar besta ao exército
        adicionarBestaButton = new JButton("Adicionar Besta");
        adicionarBestaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarBesta();
            }
        });
        painelSuperior.add(adicionarBestaButton);

        add(painelSuperior, BorderLayout.NORTH);

        // Área de texto para mostrar o progresso da batalha
        areaTexto = new JTextArea();
        areaTexto.setEditable(false);
        add(new JScrollPane(areaTexto), BorderLayout.CENTER);

        // Botão para iniciar a batalha
        iniciarBatalhaButton = new JButton("Iniciar Batalha");
        iniciarBatalhaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarBatalha();
            }
        });
        add(iniciarBatalhaButton, BorderLayout.SOUTH);
    }

    private void adicionarHeroi() {
        String heroiSelecionado = (String) comboBoxHerois.getSelectedItem();
        if (heroiSelecionado != null) {
            switch (heroiSelecionado) {
                case "Legolas (Elfo)":
                    batalha.adicionarHeroi(new Elfo("Legolas", 150, 30));
                    break;
                case "Aragorn (Humano)":
                    batalha.adicionarHeroi(new Heroi("Aragorn", 150, 50) {});
                    break;
            }
            atualizarTexto("Herói " + heroiSelecionado + " adicionado!");
        }
    }

    private void adicionarBesta() {
        String bestaSelecionada = (String) comboBoxBestas.getSelectedItem();
        if (bestaSelecionada != null) {
            switch (bestaSelecionada) {
                case "Lurtz (Orco)":
                    batalha.adicionarBesta(new Orco("Lurtz", 200, 60));
                    break;
                case "Ugluk (Troll)":
                    batalha.adicionarBesta(new Besta("Ugluk", 120, 30) {});
                    break;
            }
            atualizarTexto("Besta " + bestaSelecionada + " adicionada!");
        }
    }

    private void iniciarBatalha() {
        atualizarTexto("Batalha Iniciada!");
        batalha.iniciarBatalha();
        atualizarTexto("Batalha Finalizada!");
    }

    private void atualizarTexto(String texto) {
        areaTexto.append(texto + "\n");
    }

    public static void main(String[] args) {
        JogoInterface janela = new JogoInterface();
        janela.setVisible(true);
    }
}

