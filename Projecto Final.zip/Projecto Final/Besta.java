import java.util.Random;

public abstract class Besta extends Personagem {

    public Besta(String nome, int vida, int armadura) {
        super(nome, vida, armadura);
    }

    @Override
    public int atacar(Personagem adversario) {
        Random rand = new Random();
        int ataque = rand.nextInt(91); // Lança um dado entre 0 e 90

        // Orcos reduzem a armadura do adversário
        if (this instanceof Orco) {
            int armaduraReduzida = (int) (adversario.getArmadura() * 0.9); // Reduz 10% da armadura
            adversario.receberDano(0); // Apenas para actualizar armadura temporariamente
            adversario.armadura = armaduraReduzida;
        }

        // Calculando o dano
        if (ataque > adversario.getArmadura()) {
            return ataque - adversario.getArmadura();
        }
        return 0;
    }
}
